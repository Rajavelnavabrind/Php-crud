<html>

<head>

<title>multiple checkbox values</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>

<body>

<h3>Submit Multiple checkbox values</h3>

<form id="checkbox_form" method="POST">

 <div class="input-group">

<label>Checkbox 1</label>

<input type="checkbox" id="checkbox1" value="checkbox 1 value" name="checkbox1">

</div>

 <div class="input-group">

<label>Checkbox 2</label>

<input type="checkbox" id="checkbox2" value="checkbox 2 value" name="checkbox2">

</div>

 <div class="input-group">

<label>Checkbox 3</label>

<input type="checkbox" id="checkbox3" value="checkbox 3 value" name="checkbox3">

</div>

 <div class="input-group">

<label>Checkbox 4</label>

<input type="checkbox" id="checkbox4" value="checkbox 4 value" name="checkbox4">

</div>

<div class="input-group">

<label>Checkbox 5</label>

<input type="checkbox" id="checkbox5" value="checkbox 5 value" name="checkbox5">

</div>

<button type="submit" id="submitcheckbox" class="btn btn-sm btn-success">Submit values</button>

</form>

 

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script>

    $(function () {

        $("#checkbox_form").submit(function(e){

        e.preventDefault();

        //create an empty array

            var selected_checkboxes = new Array();

 

            //add each selected checkbox value to the array

            $("#checkbox_form input[type=checkbox]:checked").each(function () {

                selected_checkboxes.push(this.value);

            });

            var formData=new FormData(this);

            formData.append('checkboxvalues', selected_checkboxes.join(","));

           

           //display selected values using alert

            if (selected_checkboxes.length > 0) {

                alert("The selected checkbox values are : " + selected_checkboxes.join(","));

                $.ajax({

                // method used to send data for processing is POST

                method: "POST",

                // location of the file that will process data

                   url: "check.php",

                   // the form data from the input

                   data: formData,
                   contentType:false,
                   processData: false,
                  contentType: false,

                   cache:false

                 }).done(function(data){

           

                 if(data.status == "200"){

                  alert(" values submitted successfully ");

                 }

           

                 if(data.status == "300"){

           

                  alert(" an error encountered ");

                  }

           

                 });

            }else{

            alert("no value is selected")

            }

        });

    });

</script>

</body>

</html>