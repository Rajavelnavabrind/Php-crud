<?php
ini_set("display_errors","off");
$servername = "localhost";
$username = "root";
$password = "";

try {
  $conn = new PDO("mysql:host=$servername;dbname=Student", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 // echo "Connected successfully";
} catch(PDOException $e) {
 // echo "Connection failed: " . $e->getMessage();

}

	/*	
		Firstname	varchar(50)		
		Lastname	varchar(50)			
		Email	varchar(50)			
		Mobile	varchar(250)		
		Gender	varchar(50)				
		Birth	varchar(250)			
		Address	varchar(50)			
		City	varchar(50)	
		Pincode	varchar(50)				
		State	varchar(50)		
		Country	varchar(50)			
		Pincode	varchar(50)				
		Qualification	varchar(50)				
		Courses	varchar(50)	
		Filenametext*/	

if (isset($_POST['submit'])) {
$First_Name=$_POST['Fname'];
$Last_Name=$_POST['Lname'];
$Email=$_POST['Email'];
$Mobile=$_POST['Mobile']; 
$Gender=$_POST['Gender'];
$Birth=$_POST['day'].'-'.$_POST['month'].'-'.$_POST['year'] ;

$Address=$_POST['textarea'];
$City=$_POST['City'];
$Pin_Code=$_POST['Pin'];
$State=$_POST['State'];
$Country=$_POST['Country'];
$Hobbies=$_POST['check'];
$check=implode(",",$Hobbies);
$Qualification=$_POST['Qual'];
$Qual=implode(",",$Qualification);
$Courses=$_POST['Genter'];
  // Count total files
  
if($_FILES['files']['name']=='')
{
$filename=$_POST['Image']; 
}
else
{
$filename=$_FILES['files']['name'];
}  

if($_POST['files']!=''){
$target_file = 'image/'.$filename;
 if(move_uploaded_file($_FILES['files']['tmp_name'],$target_file)) {
 } 
}
   //Insert
if($_POST['Edit'] == ''){
$sql = "insert into Student (Firstname, Lastname, Email, Mobile,Gender,Birth,Address,City,Pincode,State,Country,Hobbies,Qualification,Courses,Filename)
VALUES ('".$First_Name."','".$Last_Name."','".$Email."','".$Mobile."','".$Gender."','".$Birth."','".$Address."','".$City."','".$Pin_Code."','".$State."','".$Country."','".$check."','".$Qual."','".$Courses."','".$filename."')";
}
//Update
else{ $Edit=$_POST['Edit'];
$sql="UPDATE Student SET Firstname='".$First_Name."', Lastname='".$Last_Name ."',Email='".$Email."',Mobile='".$Mobile."',Gender='".$Gender."',Birth='".$Birth."',Address='".$Address."',City='".$City."',Pincode='".$Pin_Code."',State='".$State."', Country='".$Country."', Hobbies='".$check."', Qualification='".$Qual."',Courses='".$Courses."',Filename='".$filename."' WHERE id='".$Edit."'";
}

	$conn->query($sql);
  header("Location: Select.php");
}
if (isset($_POST['Reset'])) {
	header("Location: Student.php");
}

$Edit=$_GET['Edit'];
$sql = "SELECT * FROM Student where id='".$Edit."'";   
$result = $conn->query($sql);
$row = $result->fetch();
$First=$row['Firstname'];
$Last=$row['Lastname'];
$Email=$row['Email'];
$Mobile=$row['Mobile']; 
$Gender=$row['Gender'];
$Birth=explode('-',$row['Birth']);
$Address=$row['Address'];
$City=$row['City'];
$Pin_Code=$row['Pincode'];
$State=$row['State'];
$Country=$row['Country'];
$Hobbies=$row['Hobbies'];
$repeat=explode(",",$Hobbies);
$Qualification=$row['Qualification'];
$repeat1=explode(",",$Qualification);
$Courses=$row['Courses'];
$Image=$row['Filename'];

?>
<html>
<head>
<title>Student registration </title>
<script>
function validateForm() {
	//First name
 
  var x = document.getElementById("Fname").value;
  if (x=="") {
    alert("enter Fisrt name fill out");
	document.forms["myForm"]["Fname"].focus();
	return false;
	}	
	//Lname
	var x =document.getElementById("Lname").value;
	if (x=="") {
    alert("enter Last name fill out");
	document.forms["myForm"]["Lname"].focus();
	return false;
	}	
	//Email
	var email= document.forms["myForm"]["Email"].value;
	 if (email == "") {
    alert("email fill out");
	 return false;
		}
	var mail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
			if(email.match(mail))
			{
			}
			else
			{
			alert("You have entered an invalid email address!");
			document.forms["myForm"]["Email"].focus();
			return false;
			}	
			//mobile
	var zip = document.forms["myForm"]["Mobile"].value;
	if( zip==""){
	alert("enter the mobile number fill out");
	document.forms["myForm"]["Mobile"].focus();	
	return false;
	}
	//radiobox
	var radio='false';
	if(document.getElementById('Male').checked) {
	  var radio='true';
	}else if(document.getElementById('Female').checked) {
	   var radio='true';
	}
	
	if (radio == 'false') {
    alert("Please gender");
	document.forms["myForm"]["Male"].focus();
	return false;
	}
	//Date of birth
	
		if (document.forms["myForm"]["day"].value == '') {
    alert("Please select a day");
	document.forms["myForm"]["day"].focus();
	return false;	
		}
		if (document.forms["myForm"]["month"].value == '') {
    alert("Please select a month");
	document.forms["myForm"]["month"].focus();
	return false;	
		}if (document.forms["myForm"]["year"].value == '') {
    alert("Please select a year");
	document.forms["myForm"]["year"].focus();
	return false;	
		}
	//city
		if (document.forms["myForm"]["City"].value == '') {
    alert("Please select a city");
	document.forms["myForm"]["City"].focus();
	return false;	
		}
		//pincode
		var x = document.forms["myForm"]["Pin"].value;
	if (x=="") {
    alert("enter the pincode fill out");
	document.forms["myForm"]["Pin"].focus();
	return false;
	}	
		
	//state
	var x = document.forms["myForm"]["State"].value;
	if (x=="") {
    alert("please fill out state");
	document.forms["myForm"]["State"].focus();
	return false;
	}
		
	//country
	var x = document.forms["myForm"]["Country"].value;
	if (x=="") {
    alert("please fillout country");
	document.forms["myForm"]["Country"].focus();
	return false;
	}
	
	//Hobbies
		var check= 'false';
	for (var i = 1; i <= 5; i++) {
	
	if (document.getElementById("check_"+i).checked) {
		var check= 'true';
		 }
	}
	
	if (check == 'false') {
    alert("Please fill out hobbies");
	document.forms["myForm"]["check_1"].focus();
	return false;
	}
	//Qualification
		var check= 'false';
	for (var i = 1; i <= 5; i++) {
	
	if (document.getElementById("Qual_"+i).checked) {
		var check= 'true';
		 }
	}
	
	if (check == 'false') {
    alert("Please fill out Qualification");
	document.forms["myForm"]["Qual_1"].focus();
	return false;
	}
		
	
	//courses
		var radio='false';
	if(document.getElementById('Courses1').checked) {
	  var radio='true';
	}else if(document.getElementById('Courses2').checked) {
	   var radio='true';
	}
	else if(document.getElementById('Courses3').checked) {
	   var radio='true';
	}else if(document.getElementById('Courses4').checked) {
	   var radio='true';
	}else if(document.getElementById('Courses5').checked) {
	   var radio='true';
	}else if(document.getElementById('Courses6').checked) {
	   var radio='true';
	}else if(document.getElementById('Courses7').checked) {
	   var radio='true';
	}else if(document.getElementById('Courses8').checked) {
	   var radio='true';
	}
	
	if (radio == 'false') {
    alert("Please courses fill out");
	document.forms["myForm"]["Courses1"].focus();
	return false;
	}
}
function isNumberKey(evt)
      {
		
         var charCode = (evt.which) ? evt.which : event.keyCode;
		  
         if (charCode > 31 && (charCode < 48 || charCode > 57)){
            return false;
		 }
		 var Mobile=document.getElementById("Mobile").value;
		  var j = 10;

        if(Mobile.length ==j) {
			return false;
		}
			return true;
	}
	
	function isNumberKey(evt)
      {
		
         var charCode = (evt.which) ? evt.which : event.keyCode;
		  
         if (charCode > 31 && (charCode < 48 || charCode > 57)){
            return false;
		 }
		 var Pin=document.getElementById("Pin").value;
		  var j = 6;

        if(Pin.length ==j) {
			return false;
		}
			return true;
	}

		
	
	
	
</script>

<style> 

.Form{
	color:Green;
}

</style>

</head>
<body>
<div class= Form>
<form name="myForm" id="myForm" onsubmit="return validateForm()" method="post" enctype='multipart/form-data'>
<center>
<h3>Student registration form</h3>
<table>
<input type="hidden" name="Edit" value="<?php echo $Edit; ?>">
<tr><td>First name:</td><td><input type="text" id="Fname" name="Fname" value="<?php echo $First;?>"></td></tr>
<tr><td>Last name:</td><td><input type="text" id="Lname" name="Lname"value="<?php echo $Last;?>"></td></tr>

<tr><td>Email ID:</td><td><input type="text" name="Email" id="Email" value="<?php echo $Email;?>"></td></tr>
<tr><td>Mobile Number:</td><td ><input type="text" name="Mobile" id="Mobile" onkeypress="return isNumberKey(event)" value="<?php echo $Mobile;?>" ></tr>
<tr><td>Gender</td><td><input type="radio" name="Gender" id="Male" value="Male"<?php if($Gender=='Male'){echo "checked";} ?>>Male
						<input type="radio" name="Gender"id="Female" value="Female"<?php if($Gender=='Female'){echo "checked";} ?>>Female<tr>
						
<tr><td>Date Of Birth:</td><td >						
<select name="day" id="day" >
      <option value="">Day</option>
      <option value="01"<?php if($Birth[0]=='01'){echo "selected";}  ?>>01</option>
      <option value="02"<?php if($Birth[0]=='02'){echo "selected";}  ?>>02</option>
      <option value="03"<?php if($Birth[0]=='03'){echo "selected";}  ?>>03</option>
      <option value="04"<?php if($Birth[0]=='04'){echo "selected";}  ?>>04</option>
      <option value="05"<?php if($Birth[0]=='05'){echo "selected";}  ?>>05</option>
      <option value="06"<?php if($Birth[0]=='06'){echo "selected";}  ?>>06</option>
      <option value="07"<?php if($Birth[0]=='07'){echo "selected";}  ?>>07</option>
      <option value="08"<?php if($Birth[0]=='08'){echo "selected";}  ?>>08</option>
      <option value="09"<?php if($Birth[0]=='09'){echo "selected";}  ?>>09</option>
      <option value="10"<?php if($Birth[0]=='10'){echo "selected";}  ?>>10</option>
      <option value="11"<?php if($Birth[0]=='11'){echo "selected";}  ?>>11</option>
      <option value="12"<?php if($Birth[0]=='12'){echo "selected";}  ?>>12</option>
      <option value="13"<?php if($Birth[0]=='13'){echo "selected";}  ?>>13</option>
      <option value="14"<?php if($Birth[0]=='14'){echo "selected";}  ?>>14</option>
      <option value="15"<?php if($Birth[0]=='15'){echo "selected";}  ?>>15</option>
      <option value="16"<?php if($Birth[0]=='16'){echo "selected";}  ?>>16</option>
      <option value="17"<?php if($Birth[0]=='17'){echo "selected";}  ?>>17</option>
      <option value="18"<?php if($Birth[0]=='18'){echo "selected";}  ?>>18</option>
      <option value="19"<?php if($Birth[0]=='19'){echo "selected";}  ?>>19</option>
      <option value="20"<?php if($Birth[0]=='20'){echo "selected";}  ?>>20</option>
      <option value="21"<?php if($Birth[0]=='21'){echo "selected";}  ?>>21</option>
      <option value="22"<?php if($Birth[0]=='22'){echo "selected";}  ?>>22</option>
      <option value="23"<?php if($Birth[0]=='23'){echo "selected";}  ?>>23</option>
      <option value="24"<?php if($Birth[0]=='24'){echo "selected";}  ?>>24</option>
      <option value="25"<?php if($Birth[0]=='25'){echo "selected";}  ?>>25</option>
      <option value="26"<?php if($Birth[0]=='26'){echo "selected";}  ?>>26</option>
      <option value="27"<?php if($Birth[0]=='27'){echo "selected";}  ?>>27</option>
      <option value="28"<?php if($Birth[0]=='28'){echo "selected";}  ?>>28</option>
      <option value="29"<?php if($Birth[0]=='29'){echo "selected";}  ?>>29</option>
      <option value="30"<?php if($Birth[0]=='30'){echo "selected";}  ?>>30</option>
      <option value="31"<?php if($Birth[0]=='31'){echo "selected";}  ?>>31</option>
    </select>
 <select name="month" id="month">
      <option value="">Month</option>
      <option value="01"<?php if($Birth[0]=='01'){echo "selected";}  ?>>January</option>
      <option value="02"<?php if($Birth[0]=='02'){echo "selected";}  ?>>February</option>
      <option value="03"<?php if($Birth[0]=='03'){echo "selected";}  ?>>March</option>
      <option value="04"<?php if($Birth[0]=='04'){echo "selected";}  ?>>April</option>
      <option value="05"<?php if($Birth[0]=='05'){echo "selected";}  ?>>May</option>
      <option value="06"<?php if($Birth[0]=='06'){echo "selected";}  ?>>June</option>
      <option value="07"<?php if($Birth[0]=='07'){echo "selected";}  ?>>July</option>
      <option value="08"<?php if($Birth[0]=='08'){echo "selected";}  ?>>August</option>
      <option value="09"<?php if($Birth[0]=='09'){echo "selected";}  ?>>September</option>
      <option value="10"<?php if($Birth[0]=='10'){echo "selected";}  ?>>October</option>
      <option value="11"<?php if($Birth[0]=='11'){echo "selected";}  ?>>November</option>
      <option value="12"<?php if($Birth[0]=='12'){echo "selected";}  ?>>December</option>
    </select>
    <select name="year" id="year" >
    <option value="">Year</option>
	<option value="2020"<?php if($Birth[0]=='2020'){echo "selected";}  ?>>2020</option>
    <option value="2019"<?php if($Birth[0]=='2019'){echo "selected";}  ?>>2019</option>
    <option value="2018"<?php if($Birth[0]=='2018'){echo "selected";}  ?>>2018</option>
      <option value="2017"<?php if($Birth[0]=='2017'){echo "selected";}  ?>>2017</option>
      <option value="2016"<?php if($Birth[0]=='2016'){echo "selected";}  ?>>2016</option>
      <option value="2015"<?php if($Birth[0]=='2015'){echo "selected";}  ?>>2015</option>
      <option value="2014"<?php if($Birth[0]=='2014'){echo "selected";}  ?>>2014</option>
      <option value="2013"<?php if($Birth[0]=='2013'){echo "selected";}  ?>>2013</option>
      <option value="2012"<?php if($Birth[0]=='2012'){echo "selected";}  ?>>2012</option>
      <option value="2011"<?php if($Birth[0]=='2011'){echo "selected";}  ?>>2011</option>
      <option value="2010"<?php if($Birth[0]=='2010'){echo "selected";}  ?>>2010</option>
      <option value="2009"<?php if($Birth[0]=='2009'){echo "selected";}  ?>>2009</option>
      <option value="2008"<?php if($Birth[0]=='2008'){echo "selected";}  ?>>2008</option>
      <option value="2007"<?php if($Birth[0]=='2007'){echo "selected";}  ?>>2007</option>
      <option value="2006"<?php if($Birth[0]=='2006'){echo "selected";}  ?>>2006</option>
      <option value="2005"<?php if($Birth[0]=='2005'){echo "selected";}  ?>>2005</option>
      <option value="2004"<?php if($Birth[0]=='2004'){echo "selected";}  ?>>2004</option>
      <option value="2003"<?php if($Birth[0]=='2003'){echo "selected";}  ?>>2003</option>
      <option value="2002"<?php if($Birth[0]=='2002'){echo "selected";}  ?>>2002</option>
      <option value="2001"<?php if($Birth[0]=='2001'){echo "selected";}  ?>>2001</option>
      <option value="2000"<?php if($Birth[0]=='2000'){echo "selected";}  ?>>2000</option>
      </select>
<tr>
<tr><td>Address:</td><td><textarea name="textarea" id="textarea" rows="5" col="60"><?php echo $Address;?>
</textarea></td></tr>
<tr><td>City</td>
<td><select id="City" name="City">
<option></option>
<option value="Chennai"<?php if($City=='Chennai'){echo "selected";}  ?>>Chennai,</option>
<option value="Hyderabad"<?php if($City=='Hyderabad'){echo "selected";}?>>Hyderabad</option>
<option value="Bangalore"<?php if($City=='Bangalore'){echo "selected";} ?>>Bangalore,</option>
<option value="Mumbai"<?php if($City=='Mumbai'){echo "selected";} ?>>Mumbai</option>
</select></td>
</tr>
<tr><td>Pin Code:</td><td ><input type="text" name="Pin" id="Pin"onkeypress="return isNumberKey(event)" value="<?php echo $Pin_Code;?>"></td></tr>
<tr><td>State</td><td><input type="text" id="State" name="State"value="<?php echo $State;?>"></td></tr>
<tr><td>Country</td><td><input type="text" id="Country" name="Country"value="<?php echo $Country;?>"></td></tr>
<tr><td>Hobbies</td><td>	
<input type="checkbox" name="check[0]" id="check_1" value="Drawing"<?php if(in_array('Drawing',$repeat)){ echo 'checked';}  ?>  >Drawing 
<input type="checkbox" name="check[1]" id="check_2" value="Singing"<?php if(in_array('Singing',$repeat)){ echo 'checked';}  ?>  >Singing 
<input type="checkbox" name="check[2]" id="check_3" value="Dancing"<?php if(in_array('Dancing',$repeat)){ echo 'checked';}  ?> >Dancing 
<input type="checkbox" name="check[3]" id="check_4" value="Skething"<?php if(in_array('Skething',$repeat)){ echo 'checked';}  ?> >Skethin<br>
<input type="checkbox" name="check[4]" id="check_5" value="Other"<?php if(in_array('higer',$repeat)){ echo 'checked';}  ?> >Other<input type="text" id="check_5" name="check[6]" value=""></td></tr>
<tr><td id= "qual">Qualification</td><td>
<input type="checkbox" name="Qual[0]" id="Qual_1" value="higer"<?php if(in_array('higer',$repeat1)){ echo 'checked';}  ?> >High School(10th)<br>
<input type="checkbox" name="Qual[1]" id="Qual_2" value="higerschool" <?php if(in_array('higerschool',$repeat1)){ echo 'checked';}  ?>>Higher School(12th)<br>
<input type="checkbox" name="Qual[3]" id="Qual_3" value="bachelor"<?php if(in_array('bachelor',$repeat1)){ echo 'checked';}  ?>>Graduation(Bachelors)<br>
<input type="checkbox" name="Qual[4]" id="Qual_4" value="master"<?php if(in_array('master',$repeat1)){ echo 'checked';}  ?>>Post Graduation(Master)<br>
<input type="checkbox" name="Qual[5]" id="Qual_5" value="phd"<?php if(in_array('phd',$repeat1)){ echo 'checked';}  ?>>PHD</td></tr> 
<tr><td>Courses<br> Applied For </td><td>
<input type="radio" name="Genter" id="Courses1" value="BCA"<?php if($Courses=='BCA'){echo "checked";} ?>>BCA(Bachelors Of Computer Appication)<br>
<input type="radio" name="Genter" id="Courses2" value="B.Com"<?php if($Courses=='B.Com'){echo "checked";} ?>>B.Com(Bachelors Of Commerce)<br>
<input type="radio" name="Genter" id="Courses3" value="B.Se"<?php if($Courses=='B.Se'){echo "checked";} ?>>B.Se(Bechelors Of bscience)<br>
<input type="radio" name="Genter" id="Courses4" value="BA" <?php if($Courses=='BA'){echo "checked";} ?>>BA(Bachelors Of Arts)<br>
<input type="radio" name="Genter" id="Courses5" value="MSC" <?php if($Courses=='MSC'){echo "checked";} ?>>MSC(Master Of Computer Application)<br>
<input type="radio" name="Genter" id="Courses6" value="M.Com"<?php if($Courses=='M.Com'){echo "checked";} ?> >M.Com(Master Of Commerce)<br>
<input type="radio" name="Genter" id="Courses7" value="M.Se" <?php if($Courses=='M.Se'){echo "checked";} ?>>M.Se(Master Of Science)<br>
<input type="radio" name="Genter" id="Courses8" value="MA" <?php if($Courses=='MA'){echo "checked";} ?>>MA(Master Of Arts)<tr>
<input type="hidden" name="Image" value="<?php echo $Image; ?>">
<tr><td>File Name:</td><td ><input type="file" name="files" /><span><?php echo $Image;?></span></td></tr>
<tr><td></td><td></center><button name="submit" value="Submit">submit</button><button name="Reset" value="Reset">Reset</button></center></td></tr>
</table>
</center>				
</form>
</div>
</body>
</html>
