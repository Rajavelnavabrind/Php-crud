<?php


class rajavel

{
    public $oldcompany="mundra solar";

    function newjoin($name)
    {
        //echo $name;
        echo"<br>";
        echo "__function__<br>";
        echo __FUNCTION__;
        echo"<br>-----------<br>";
        echo "__class__<br>";
        echo __CLASS__;
        echo "<br>----------<br>";
        echo "__line__<br>";
        echo __LINE__;
        echo"<br>-----------<br>";
        echo "__file__<br>";
        echo __FILE__;
        echo"<br>-----------<br>";
        



    
    }

}
$obj=new rajavel();
//echo $obj->oldcompany;
echo "<br>";
$obj->newjoin("new join  navabrind");
//$obj->oldcompany="vrm";
echo "<br>";
//echo $obj->oldcompany;
//$obj->oldcompany=" rajavel";
//echo $obj->oldcompany;


?>