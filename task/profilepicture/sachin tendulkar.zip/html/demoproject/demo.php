<?php

setcookie("user","test",time()+(60*60*24*10),"/");
print_r($_COOKIE);


?>