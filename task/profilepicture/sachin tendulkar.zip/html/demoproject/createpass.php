<?php

echo "<h1> PASSWORD CREATED SUCCESSFUL</h1>";
echo '<br>';	
echo "<h2> your new password is</h2>".$_POST['cnew'];
?>
