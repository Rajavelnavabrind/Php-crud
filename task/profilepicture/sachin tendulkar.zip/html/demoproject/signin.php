<?php
   $servername = "localhost";
   $username = "root";
   $password = "Password@123";
   $dbname = "myDB";
   // Create connection
   $conn = new mysqli($servername, $username, $password, $dbname);
   
   $user=$_POST['username'];
   	$pass=$_POST['password'];
   //insert query
   $sql = "INSERT INTO register_form(fldusername,fldpassword) VALUES('$user','$pass')";
   
   echo $sql;
   $sql1=mysqli_query($conn,$sql);
   echo "<br>";
   echo "<br>";
   $sql2="SELECT id, fldusername,fldpassword FROM register_form";//select query
   echo $sql2;
   $select=mysqli_query($conn,$sql2);
   
   $sql3= "DELETE FROM register_form WHERE id=10";//delete query
   $delete=mysqli_query($conn,$sql3);
   
   	echo"<h1>REGISTRATION IS SUCCESSFUL</h1>";
   
       echo "your username is   ".$_POST['username'];
    echo"<br>";
   echo "your password is   ".$_POST['password'];
   
   echo"<br>-------------------------------------------<br>";
   echo "<h1> VIEW data given below </h1>";
   if ($select->num_rows > 0) {
       // output data of each row
       while($row = $select->fetch_assoc()) {
           echo "<br> id: ". $row["id"]. " - Username ". $row["fldusername"]."password " . $row["fldpassword"] . "<br>";
       }
   } else {
       echo "0 results";
   }
   
   $conn->close();
   
   echo"<br>-------------------------------------------<br>";
   
   if ($delete == TRUE) {
   	echo "Record deleted successfully";
    return false;
     } else {
   	echo "Error deleting record: " . mysqli_error($conn);
     }
     
     mysqli_close($conn);
   
   	
   
   
   ?>