<?php
$server="localhost";
$user="root";
$pass="Password@123";
$db="myDB";
$con=new mysqli($server,$user,$pass,$db);
$f_name=$_POST['fname'];
$l_name=$_POST['lname'];
$s_name=$_POST['sname'];
$e_mail=$_POST['email'];
$m_mobile=$_POST['mobile'];
$g_gender=$_POST['gender'];
$username=$_POST['user'];
$password=$_POST['pass'];
$c_pass=$_POST['cpass'];
$con1="INSERT INTO createaccount_form(fname,lname,surename,email,mobile,gender,username,password,c_password)VALUES('$f_name','$l_name','$s_name','$e_mail',$m_mobile,'$g_gender','$username',$password,$c_pass)";
echo $con1;
$con2=mysqli_query($con,$con1);
$sql="UPDATE createaccount_form SET lname='ram' WHERE id=2";
echo $sql;
$connect=mysqli_query($con,$sql);
echo " CREATED ACCOUNT  AN SUCCESSFUL  ";
echo"<br>";
echo " Your name is ".$_POST['sname'];
echo"<br>";
echo " Your Email is ".$_POST['email'];
echo"<br>";
echo " Your mobile no is ".$_POST['mobile'];
echo"<br>";
echo " Your Gender is ".$_POST['gender'];
echo"<br>";
echo " Your Username is ".$_POST['user'];
echo"<br>";
echo " Your password is ".$_POST['pass'];

?>