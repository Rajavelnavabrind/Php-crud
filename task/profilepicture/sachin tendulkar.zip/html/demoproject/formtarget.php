<html>
<body>

<h1>The form target attribute</h1>

<form action="second.php" method="get" target="_blank">
        
  <label for="fname">First name:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="lname">Last name:</label>
  <input type="text" id="lname" name="lname"><br><br>
  <input type="submit" value="Submit">
        
        

</form>
        <form action="new1.php" method="get" target="_blank">
                <input type='submit' value='Forgetten password'>
	
        </form>

</body>
</html>
