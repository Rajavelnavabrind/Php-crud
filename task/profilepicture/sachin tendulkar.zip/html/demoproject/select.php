<?php
$servername="localhost";
$username="root";
$password="Password@123";
$db="myDB";
$con1=new mysqli($servername,$username,$password,$db);


$user=$_GET['user'];

$con2 = "SELECT * FROM createaccount_form  WHERE username='$user'";
$con3 = mysqli_query($con1,$con2);
$result = mysqli_num_rows($con3);
echo json_encode($result);



?>