<html>
	<body>
	<form action="createpass.php" method ='get' target="_blank">
		<label>Create New password</label>
		<input type='text' name='new'><br>
		<label>Confirm  password</label>
		<input type='text' name='cnew'>
		
		<input type='submit' value='create' name='submit'>
	</body>
	</html