<html>
   <body>
      <h1 style ="background-color:yellow";> CREATE ACCOUNT </h1>
      <h1 >
         <form action='submit.php' method='post' target="_blank">
           	
            <tr>
            <label for="fname">First name:</label>
            <input type="text" id="fname" name="fname"><br>
            </tr>		
            <tr>
               <td>
                     <label for="lname">Last name:</label>
               </td> 
                <td>
                     <input type="text" id="lname" name="lname"><br>
               </td>  
            </tr>
            <tr>
               <td>
                     <label for="sname">Sure name:</label>
                     <input type="text" id="sname" name="sname"><br>
               </td>  
            </tr>
            <tr>
               <td>
                  <label> Email </label>
               </td>
            </tr>
            <tr>
               <td>
                   <input type="text"  name="email"><br>
               </td>
              </tr>
            <tr>
            <label> Mobile no :</label>
            <input type="number"  name="mobile"><br>
            </tr>
            <tr>
            <label> Gender:</label>
            Male <input type="radio"  name="gender" value="male">
            Female <input type="radio"  name="gender" value="female"><br>
            </tr>
            <tr>
                  <label> Username :</label>
                  <input type="text"  name="user" 
                  onchange="myfunc(this.value)"><br>
            </tr>
            <tr>
            <label> password:</label>
            <input type="text"  name="pass"><br>
            </tr>
            <tr>
             <th><label>confirm password:</label></th>
            <input type="text"  name="cpass"><br>
            </tr>
            <input type="reset" value="Reset">	
            <br>
            <input type='submit' value='Submit' id="btnSubmit">

         </form>
      </h1>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script>
         function myfunc(val)
         {
            var data = {
               user:val
            }
            $.getJSON("./select.php?" + $.param(data), function (res) {
               if(res > 0)
               {
                  alert("username already exist");
                  $("#btnSubmit").hide();
               } else {
                  $("#btnSubmit").show();
               }
            });
         };

         var str="god is great";
         console.log(str);
         var str_1="good";
         var str_2="morning";
         var str_3=str_1+'-'+str_2;
         console.log(str_3);

         
      </script>
   </body>
</html>

