<html>
   <body>
      <center>
         <body bgcolor="white">
            <h1> REGISTRATION PAGE </h1>
            <form name="f1" method="post" action="signin.php" target="_blank">
               <label> USER NAME </lable>
               <input type="text" name='username'><br><br>
               <label> PASSWORD </lable>
               <input type="password" name='password'><br><br>
               <input type='submit' value='sign in' 
                  onclick="return validation();">	
               <input type='submit' value='create account'
                  onclick="f1.action='createaccount.php';  return true;">
               <input type='submit' value='Forgetten password'
                  onclick="f1.action='forget.php';  return true;">	
            </form>
      </center>
      <script>
         function validation()
         {
         	var name=document.f1.username.value;
         	 var password=document.f1.password.value;
         
         	if(name==null || name=="")
         	{
         		alert("username is blank");
         
         		return false;
         	}
            else if(password==null || password=="")
            {

         		alert("password is blank");
         
               return false;
            }
            

         	
         }
      </script>
   </body>
</html>
