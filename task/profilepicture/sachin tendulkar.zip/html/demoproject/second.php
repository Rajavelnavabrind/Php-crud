<?php

echo "welcome  "  .$_POST['name'];
echo "<br>";
echo "Your email id  ".$_POST["email"];
echo "<br>";
echo "your mobile ".$_POST["phone"];


?>
