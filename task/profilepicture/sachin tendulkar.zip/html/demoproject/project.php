<html>
<body>
<h1>  Registration page</h1>

<form action="second.php" method="get">
<label>Name=</label>
<input type="text" name="name"><br>
Email=<input type="text" name="email"><br>
mobile<input type="text" name="phone"><br>
<button>click</button>
</form>

</body>
</html>
