<html>
	<body>
		<h1> FORGET PASSWORD</h1>
		
		<label> USER NAME</label>
<input type="text" name"user">
		<form action="passwors.php" method="get" target="_blank">
		<input type="submit">
	</body>
</html>
		